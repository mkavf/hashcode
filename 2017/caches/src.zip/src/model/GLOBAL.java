package model;

public class GLOBAL {
    public static int CACHE_SIZE;
}
